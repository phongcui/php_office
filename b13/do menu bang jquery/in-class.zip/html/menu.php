<?php
require_once('data.php');

$xhtmlMenu = '';
foreach ($arrMenu as $keyLevelOne => $menuLevelOne) {
    if (isset($menuLevelOne['child'])) {
        $classActive = ($keyLevelOne == $menuCurrent) ? 'class="active"' : '';
        
        if (in_array($menuCurrent, array_keys($menuLevelOne['child']))) {
            $classActive = 'class="active"';
        }

        if(isset($menuLevelOne['child'][$menuCurrent]))  $classActive = 'class="active"';

        foreach ($menuLevelOne['child'] as $menuLevelTwo) {
            if(isset($menuLevelTwo['child'][$menuCurrent]))  $classActive = 'class="active"';
        }

        $xhtmlMenu .= sprintf('<li %s><a href="%s">%s</a><ul>', $classActive, $menuLevelOne['link'], $menuLevelOne['name']);

        foreach ($menuLevelOne['child'] as $keyLevelTwo => $menuLevelTwo) {
            if (isset($menuLevelTwo['child'])) {
                $xhtmlMenu .= sprintf('<li><a href="%s">%s</a><ul>', $menuLevelTwo['link'], $menuLevelTwo['name']);

                foreach ($menuLevelTwo['child'] as $keyLevelThree => $menuLevelThree) {
                    $xhtmlMenu .= sprintf('<li><a href="%s">%s</a></li>', $menuLevelThree['link'], $menuLevelThree['name']);
                }

                $xhtmlMenu .= '</ul></li>';
            } else {
                $xhtmlMenu .= sprintf('<li><a href="%s">%s</a></li>', $menuLevelTwo['link'], $menuLevelTwo['name']);
            }
        }

        $xhtmlMenu .= '</ul></li>';
    } else {
        $classActive = ($keyLevelOne == $menuCurrent) ? 'class="active"' : '';
        $xhtmlMenu .= sprintf('<li %s><a href="%s">%s</a></li>', $classActive, $menuLevelOne['link'], $menuLevelOne['name']);
    }
}
?>

<div class="menuBackground">
    <div class="center">
        <ul class="dropDownMenu">
            <?php echo $xhtmlMenu; ?>
        </ul>
    </div>
</div>