<div class="breadcrumb">
         <a href="index.php">Home</a>
         <span>></span>
         <a href="data/about.php">About</a>
         <span>></span>
         <span>Company</span>
      </div>