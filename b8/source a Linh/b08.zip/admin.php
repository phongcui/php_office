<?php

?>



<form action="" method="post">
    <input type="text" value="<?= $timeout ?>">
    <button type="submit">Save</button>
</form>
