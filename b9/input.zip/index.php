<!DOCTYPE html>
<html dir="ltr" lang="en-US">

<head>
    <?php require_once 'html/head.php' ?>
</head>

<body class="stretched overlay-menu">

    <div id="wrapper" class="clearfix bg-light">



        <header id="header" class="full-header dark">
            <div id="header-wrap">
                <div class="container">
                    <div class="header-row">

                        <!-- Logo -->
                        <div id="logo">
                            <a href="index.php" class="standard-logo"><span class="p-1">ZendVN</span></a>
                            <a href="index.php" class="retina-logo"><span class="p-1">ZendVN</span></a>
                        </div>
                        <!-- #logo end -->

                        <div id="primary-menu-trigger">
                            <svg class="svg-trigger" viewBox="0 0 100 100">
                                <path d="m 30,33 h 40 c 3.722839,0 7.5,3.126468 7.5,8.578427 0,5.451959 -2.727029,8.421573 -7.5,8.421573 h -20"></path>
                                <path d="m 30,50 h 40"></path>
                                <path d="m 70,67 h -40 c 0,0 -7.5,-0.802118 -7.5,-8.365747 0,-7.563629 7.5,-8.634253 7.5,-8.634253 h 20"></path>
                            </svg>
                        </div>

                        <!-- Primary Navigation -->
                        <nav class="primary-menu text-lg-center">
                            <ul class="menu-container">
                                <li class="menu-item">
                                    <a class="menu-link" href="#">
                                        <div>Login</div>
                                    </a>
                                </li>
                            </ul>
                        </nav>
                        <!-- #primary-menu end -->
                    </div>
                </div>
            </div>
            <div class="header-wrap-clone" style="height: 62px"></div>
        </header>

        <div class="container">
            <div class="row">
                <!-- Content -->
                <section id="content" class="bg-light">

                    <div class="content-wrap pt-lg-0 pt-xl-0 pb-0">

                        <div class="container clearfix">

                            <div class="heading-block border-bottom-0 center pt-4 mb-3">
                                <h3>Tin tức</h3>
                            </div>

                            <!-- Posts -->
                            <div class="row grid-container infinity-wrapper clearfix">

                                <div class="col-md-6 p-3">
                                    <div class="entry mb-1 clearfix">
                                        <div class="entry-image mb-3">
                                            <a href="images/items/lightbox/1.jpg" data-lightbox="image" style="background: url('images/items/1.jpg') no-repeat center center; background-size: cover; height: 278px;"></a>
                                        </div>
                                        <div class="entry-title">
                                            <h3><a href="#">Bộ Y tế đề xuất đặt mua vaccine Covid-19 của Nga</a></h3>
                                        </div>
                                        <div class="entry-content">
                                            <p>Ông Vũ Tuấn Cường, Cục trưởng Quản lý Dược, Bộ Y tế, chiều 14/8 cho biết đã đề xuất đặt mua vaccine Covid-19 từ Nga.</p>
                                        </div>
                                        <div class="entry-meta no-separator nohover">
                                            <ul class="justify-content-between mx-0">
                                                <li><i class="icon-calendar2"></i> 14/08/2020 15:36:32</li>
                                                <li>vnexpress.net</li>
                                            </ul>
                                        </div>
                                        <div class="entry-meta no-separator hover">
                                            <ul class="mx-0">
                                                <li><a href="#">Xem &rarr;</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 p-3">
                                    <div class="entry mb-1 clearfix">
                                        <div class="entry-image mb-3">
                                            <a href="images/items/lightbox/1.jpg" data-lightbox="image" style="background: url('images/items/1.jpg') no-repeat center center; background-size: cover; height: 278px;"></a>
                                        </div>
                                        <div class="entry-title">
                                            <h3><a href="#">Bộ Y tế đề xuất đặt mua vaccine Covid-19 của Nga</a></h3>
                                        </div>
                                        <div class="entry-content">
                                            <p>Ông Vũ Tuấn Cường, Cục trưởng Quản lý Dược, Bộ Y tế, chiều 14/8 cho biết đã đề xuất đặt mua vaccine Covid-19 từ Nga.</p>
                                        </div>
                                        <div class="entry-meta no-separator nohover">
                                            <ul class="justify-content-between mx-0">
                                                <li><i class="icon-calendar2"></i> 14/08/2020 15:36:32</li>
                                                <li>vnexpress.net</li>
                                            </ul>
                                        </div>
                                        <div class="entry-meta no-separator hover">
                                            <ul class="mx-0">
                                                <li><a href="#">Xem &rarr;</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Infinity Scroll Loader
					============================================= -->
                            <div class="text-center">
                                <div class="page-load-status hovering-load-status">
                                    <div class="css3-spinner infinite-scroll-request">
                                        <div class="css3-spinner-ball-pulse-sync">
                                            <div></div>
                                            <div></div>
                                            <div></div>
                                        </div>
                                    </div>
                                    <div class="alert alert-warning center infinite-scroll-last mx-auto" style="max-width: 20rem;">End of content</div>
                                    <div class="alert alert-warning center infinite-scroll-error mx-auto" style="max-width: 20rem;">No more pages to load</div>
                                </div>
                            </div>
                            <div class="center d-none">
                                <a href="demo-modern-blog-2.html" class="load-next-posts"></a>
                            </div>

                        </div>

                    </div>
                </section>
                <!-- #content end -->

                <section class="right-side mb-4">
                    <div class="container">
                        <div class="row">
                            <div class="col-12">
                                <div class="box mt-4">
                                    <h3 class="mb-1">Giá vàng</h3>
                                    <div class="card card-body">
                                        <table class="table table-sm">
                                            <thead>
                                                <tr>
                                                    <th><b>Loại vàng</b></th>
                                                    <th><b>Mua vào</b></th>
                                                    <th><b>Bán ra</b></th>
                                                </tr>
                                            </thead>
                                            <tbody>

                                                <tr>
                                                    <td>Vàng SJC 1L - 10L</td>
                                                    <td>54.630.000</td>
                                                    <td>56.670.000</td>
                                                </tr>

                                                <tr>
                                                    <td>Vàng nhẫn SJC 99,99 1 chỉ, 2 chỉ, 5 chỉ</td>
                                                    <td>52.400.000</td>
                                                    <td>54.000.000</td>
                                                </tr>

                                                <tr>
                                                    <td>Vàng nhẫn SJC 99,99 0,5 chỉ</td>
                                                    <td>52.400.000</td>
                                                    <td>54.100.000</td>
                                                </tr>

                                                <tr>
                                                    <td>Vàng nữ trang 99,99%</td>
                                                    <td>51.900.000</td>
                                                    <td>53.500.000</td>
                                                </tr>

                                                <tr>
                                                    <td>Vàng nữ trang 99%</td>
                                                    <td>50.670.000</td>
                                                    <td>52.970.000</td>
                                                </tr>

                                                <tr>
                                                    <td>Vàng nữ trang 75%</td>
                                                    <td>37.479.000</td>
                                                    <td>40.279.000</td>
                                                </tr>

                                                <tr>
                                                    <td>Vàng nữ trang 58,3%</td>
                                                    <td>28.544.000</td>
                                                    <td>31.344.000</td>
                                                </tr>

                                                <tr>
                                                    <td>Vàng nữ trang 41,7%</td>
                                                    <td>19.662.000</td>
                                                    <td>22.462.000</td>
                                                </tr>

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <div class="box mt-4">
                                    <h3 class="mb-1">Giá coin</h3>
                                    <div class="card card-body">
                                        <table class="table table-sm">
                                            <thead>
                                                <tr>
                                                    <th><b>Name</b></th>
                                                    <th><b>Price</b></th>
                                                    <th><b>Change (24h)</b></th>
                                                </tr>
                                            </thead>
                                            <tbody>

                                                <tr>
                                                    <td>Bitcoin</td>
                                                    <td>$11,704.1800</td>
                                                    <td><span class="text-success">2.82%</span></td>
                                                </tr>

                                                <tr>
                                                    <td>Ethereum</td>
                                                    <td>$423.9700</td>
                                                    <td><span class="text-success">11.11%</span></td>
                                                </tr>

                                                <tr>
                                                    <td>XRP</td>
                                                    <td>$0.2930</td>
                                                    <td><span class="text-success">6.73%</span></td>
                                                </tr>

                                                <tr>
                                                    <td>Tether</td>
                                                    <td>$0.9998</td>
                                                    <td><span class="text-danger">-0.18%</span></td>
                                                </tr>

                                                <tr>
                                                    <td>ChainLink</td>
                                                    <td>$17.0700</td>
                                                    <td><span class="text-success">4.84%</span></td>
                                                </tr>

                                                <tr>
                                                    <td>Bitcoin Cash</td>
                                                    <td>$292.2900</td>
                                                    <td><span class="text-success">5.41%</span></td>
                                                </tr>

                                                <tr>
                                                    <td>Cardano</td>
                                                    <td>$0.1396</td>
                                                    <td><span class="text-success">4.56%</span></td>
                                                </tr>

                                                <tr>
                                                    <td>Bitcoin SV</td>
                                                    <td>$210.4800</td>
                                                    <td><span class="text-success">4.77%</span></td>
                                                </tr>

                                                <tr>
                                                    <td>Litecoin</td>
                                                    <td>$56.3400</td>
                                                    <td><span class="text-success">6.84%</span></td>
                                                </tr>

                                                <tr>
                                                    <td>Binance Coin</td>
                                                    <td>$21.7100</td>
                                                    <td><span class="text-success">4.46%</span></td>
                                                </tr>

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </section>
            </div>
        </div>

        <footer>
            <div id="copyrights" class="bg-dark dark">
                <div class="container clearfix">

                    <div class="row col-mb-30">
                        <div class="col-12 text-center text-muted">
                            Copyrights &copy; 2020 All Rights Reserved by ZendVN Inc.<br>
                        </div>
                    </div>

                </div>
            </div>
        </footer>
    </div>

    <!-- Go To Top
	============================================= -->
    <div id="gotoTop" class="icon-angle-up rounded-circle"></div>

    <?php require_once 'html/script.php' ?>
</body>

</html>